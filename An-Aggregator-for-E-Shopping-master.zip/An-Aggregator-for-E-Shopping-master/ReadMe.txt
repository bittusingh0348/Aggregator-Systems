  An Aggregator for E-Shopping 
---------------------------------

An application which displays price of any product available on different e-commerce stores.
User is able to search via product title. Can sort it in asscending/ descending order for comparing prices.

Software Requirements
-----------------------
Python 2.7/ Sqlite3/ Flask

Installation
----------------
install python, pip, flask etc. and all required libraries.
go to aggregator -> 
python aggregator.py

will run in local server.
